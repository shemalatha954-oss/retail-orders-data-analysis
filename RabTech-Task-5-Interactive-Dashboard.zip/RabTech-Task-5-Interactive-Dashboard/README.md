# RabTech Task 05 — Interactive Dashboard & KPI Visualizations

An interactive Streamlit/Plotly business dashboard with revenue, order volume, average order value, marketing spend per purchasing customer (proxy), monthly trends, category and regional comparisons, filters, drill-down data, CSV download, and KPI summary PDF export.

## Run locally
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Deploy
1. Upload `app.py`, `requirements.txt`, and `README.md` to a public GitHub repository.
2. Go to https://share.streamlit.io/ and deploy the repository with `app.py` as the entry point.
3. Copy the public Streamlit URL into the RabTech deliverable form.

## Input data
Optional CSV columns: `date`, `region`, `category`, `revenue`, `customer_id`, `marketing_spend`.
Without an upload, the app uses reproducible **synthetic demonstration data**.

## KPI limitations
True CAC requires the number of **newly acquired** customers, and churn requires historical active/inactive customer status. These are not inferred from transaction data. The marketing spend / unique purchasing customer metric is explicitly labeled a proxy and is not true CAC.

## Export
The PDF export is a KPI summary report, not a screenshot of all interactive charts. Use browser Print > Save as PDF if a visual dashboard PDF is needed.
