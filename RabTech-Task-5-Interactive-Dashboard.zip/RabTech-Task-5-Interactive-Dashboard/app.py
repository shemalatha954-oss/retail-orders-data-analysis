import io
import numpy as np
import pandas as pd
import plotly.express as px
import streamlit as st
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas

st.set_page_config(page_title='RabTech Business KPI Dashboard', page_icon='📊', layout='wide')
st.title('📊 Interactive Business KPI Dashboard')
st.caption('RabTech Task 05 | Demo dataset — replace with real business data for actual insights')

@st.cache_data
def demo_data():
    rng = np.random.default_rng(42)
    dates = pd.date_range('2025-01-01', periods=365)
    n = 1800
    df = pd.DataFrame({
        'date': rng.choice(dates, n),
        'region': rng.choice(['North', 'South', 'East', 'West'], n),
        'category': rng.choice(['Electronics', 'Fashion', 'Home', 'Grocery'], n),
        'revenue': rng.integers(500, 15000, n),
        'customer_id': rng.integers(1, 450, n),
        'marketing_spend': rng.integers(30, 600, n),
    })
    return df.sort_values('date')

uploaded = st.file_uploader('Optional: upload your own sales CSV', type='csv')
if uploaded:
    df = pd.read_csv(uploaded)
    required = {'date','region','category','revenue','customer_id','marketing_spend'}
    if not required.issubset(df.columns):
        st.error('CSV must contain: ' + ', '.join(sorted(required)))
        st.stop()
    df['date'] = pd.to_datetime(df['date'], errors='coerce')
    for field in ['revenue', 'marketing_spend']:
        df[field] = pd.to_numeric(df[field], errors='coerce')
    df = df.dropna(subset=['date','revenue','marketing_spend','customer_id','region','category'])
else:
    df = demo_data()

if df.empty:
    st.warning('No valid records found.')
    st.stop()

st.sidebar.header('Filters')
regions = st.sidebar.multiselect('Region', sorted(df.region.unique()), default=sorted(df.region.unique()))
categories = st.sidebar.multiselect('Category', sorted(df.category.unique()), default=sorted(df.category.unique()))
min_date, max_date = df.date.min().date(), df.date.max().date()
period = st.sidebar.date_input('Date range', value=(min_date, max_date), min_value=min_date, max_value=max_date)
if not isinstance(period, (tuple, list)) or len(period) != 2:
    st.info('Select both start and end dates.')
    st.stop()
start, end = period
filtered = df[df.region.isin(regions) & df.category.isin(categories) & df.date.dt.date.between(start, end)]
if filtered.empty:
    st.warning('No records match these filters.')
    st.stop()

revenue = float(filtered.revenue.sum())
orders = len(filtered)
customers = filtered.customer_id.nunique()
spend = float(filtered.marketing_spend.sum())
aov = revenue / orders if orders else 0
# New customer acquisition and churn require customer history, not just transaction rows.
# Marketing spend / unique purchasing customers is a proxy, NOT true CAC.
spend_per_customer = spend / customers if customers else 0
c1,c2,c3,c4 = st.columns(4)
c1.metric('Revenue', f'₹{revenue:,.0f}')
c2.metric('Orders', f'{orders:,}')
c3.metric('Average Order Value', f'₹{aov:,.0f}')
c4.metric('Marketing Spend / Customer (proxy)', f'₹{spend_per_customer:,.0f}')
st.info('True Customer Acquisition Cost (CAC) and Churn Rate cannot be calculated from sales transactions alone. CAC requires new-customer counts; churn requires active/inactive customer history.')

monthly = filtered.assign(month=filtered.date.dt.to_period('M').astype(str)).groupby('month', as_index=False)['revenue'].sum()
by_cat = filtered.groupby('category', as_index=False)['revenue'].sum()
by_region = filtered.groupby('region', as_index=False)['revenue'].sum()
left,right = st.columns(2)
with left:
    st.plotly_chart(px.area(monthly, x='month', y='revenue', title='Monthly Revenue Trend', markers=True), use_container_width=True)
    st.plotly_chart(px.bar(by_region, x='region', y='revenue', title='Revenue by Region', color='region'), use_container_width=True)
with right:
    st.plotly_chart(px.pie(by_cat, names='category', values='revenue', title='Category Revenue Share', hole=.45), use_container_width=True)
    st.plotly_chart(px.bar(by_cat, x='category', y='revenue', title='Category Comparison', color='category'), use_container_width=True)

st.subheader('Drill-down Data')
st.dataframe(filtered, use_container_width=True)
st.download_button('Download filtered CSV', filtered.to_csv(index=False).encode('utf-8'), 'filtered_sales.csv', 'text/csv')

buffer = io.BytesIO()
pdf = canvas.Canvas(buffer, pagesize=A4)
pdf.setFont('Helvetica-Bold', 17)
pdf.drawString(40, 800, 'Business KPI Dashboard - Summary')
pdf.setFont('Helvetica', 11)
lines = [f'Period: {start} to {end}', f'Revenue: INR {revenue:,.2f}', f'Orders: {orders}', f'Unique customers: {customers}', f'Average order value: INR {aov:,.2f}', f'Marketing spend per purchasing customer (proxy): INR {spend_per_customer:,.2f}', 'Note: CAC and churn require additional customer history.']
for i, line in enumerate(lines):
    pdf.drawString(40, 760 - i*25, line)
pdf.save()
st.download_button('Export KPI Summary PDF', buffer.getvalue(), 'dashboard_summary.pdf', 'application/pdf')
